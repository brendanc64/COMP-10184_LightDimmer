#include <Arduino.h>

int analogValue;
int button;
bool power;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  // Recognize LED and Button
  pinMode(D5, INPUT_PULLUP);
  pinMode(D4, OUTPUT);

  analogWriteRange(1023);

  // LED should be off to start
  power = false;
  digitalWrite(D4, HIGH);
}

void loop() {
  // put your main code here, to run repeatedly:


  Serial.println("\n");
  // take in when the button is pressed
  button = digitalRead(D5);


  // Check power state:
  if (power == true) {

    Serial.println("checking TRUE pwr state");
    // keep LED on
    digitalWrite(D4, LOW);
    // using the knob to change brightness
    analogValue = analogRead(A0);
    analogWrite(D4, analogValue);

    // check for button press
    if (button == 0) {
      // turn off LED
      power = false;
    }
  }

  else if (power == false){

    Serial.println("checking FALSE pwr state");
    // keep LED off
    digitalWrite(D4, HIGH);

    // check for button press
    if (button == 0) {
      // turn on LED
      power = true;
    }
  }

  
  Serial.println("Button value: " + String(button));
  Serial.println("Value of Knob: " + String(analogValue));
  Serial.println("Power State: " + String(power));

  delay(2000);
}